<!doctype html>
<html>
    <head>
        <link rel = "stylesheet" type = "text/css" href = "stylesheet.css">
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <script src = "js/jquery-3.3.1.min.js"></script>
        <script src = "js/script.min.js"></script>
    </head>
    <body>
        <header>
            <section class = "banner">
                <h1>Cougars Den - Build Your Own Pizza</h1>
                <img src = "images/OCLOGO.png" alt = "Seal of Old Colony R.V.T.H.S"/>
            </section>
        </header>
        <main>
            <p id = "thanks">thank you for ordering from the Cougars Den!</p>
            <a href = "index.html"><button id = "thanksButton">Back to Order Page</button></a>
        </main>
        <footer>
        </footer>
    </body>
</html>
