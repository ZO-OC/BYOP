<?php
    include 'dbh.inc.php';
    $sql = "DELETE FROM pizza WHERE status = 'resolved'";
    mysqli_query($con, $sql);
    header("Location: ../orders.php?deletecache=success");
    exit();
?>