<?php
include 'dbh.inc.php';
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $top = $_POST['top'];
    $status = "not resolved";
    if (empty($name) || empty($email) || empty($top)) {
        header("Location: ../index.html?error=emptyfields");
        exit();
    } else {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          header("Location: ../index.html?error=invalidemail");  
          exit();
        } else {
          $sql = "INSERT INTO pizza (name, email, top, status) VALUES ('$name', '$email', '$top', '$status');";
          mysqli_query($con, $sql);
          header("Location: ../base.html");
          exit();
        }
    }
} else {
    header("Location: ../index.html?error=bot");
    exit();
}
?>