<?php
    include 'dbh.inc.php';
    $id = $_POST['id'];
    $sql = "UPDATE pizza SET status = 'resolved' WHERE id = '$id'";
    mysqli_query($con, $sql);
    header("Location: ../orders.php?resolve=success");
    exit();
?>