<?php
    include 'dbh.inc.php';
    $id = $_POST['id'];
    $sql = "UPDATE pizza SET status = 'not resolved' WHERE id = '$id'";
    mysqli_query($con, $sql);
    header("Location: ../cache.php?unresolve=success");
    exit();
?>