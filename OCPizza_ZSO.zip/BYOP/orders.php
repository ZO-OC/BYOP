<!doctype html>
<html>
    <head>
        <link rel = "stylesheet" type = "text/css" href = "stylesheet.css">
        <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
        <style>
            body, html {
                background-image: url("");
            }
            main {
                padding: 0% 0% 0% 0%;
                position: static; 
            }
        </style>
    </head>
    <body>
        <header>
            <section class = "banner">
                <h1>Cougars Den - Build Your Own Pizza</h1>
                <img src = "images/OCLOGO.png" alt = "Seal of Old Colony R.V.T.H.S"/>
            </section>
        </header>
        <main>
            <section class = "title">
                <p>Current Orders</p>
                <a href = "cache.php"><button>View Cache</button></a>
            </section>
            <section class = "orders">
                <?php
                    
                    
                    $con = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
                    
                    $i = 0;
                    
                    $sql = "SELECT * FROM pizza WHERE status = 'not resolved'";
                    $result = mysqli_query($con, $sql);
                    $resultCheck = mysqli_num_rows($result); 
                    
                    if ($resultCheck < 1) {
                        
                        echo '<section class = "ordersZero">
                                <p>No active orders to view</p>
                              </section>';
                        echo "\n";     
                        
                    } else {
                    
                        do {
                            
                            /* https://stackoverflow.com/questions/16568/how-to-select-the-nth-row-in-a-sql-database-table LIMIT 1 OFFSET 1. THIS IS SELECTING THE SECOND ROW OF ALL THE ROWS WITH A STATUS OF 'RESOLVED'. IF WE WANTED THE THIRD ROW WE WOULD DO LIMIT 1 OFFSET 2 */
                            
                            $sql = "SELECT * FROM pizza WHERE status = 'not resolved' LIMIT 1 OFFSET $i";
                            $result = mysqli_query($con, $sql);
                            $resultCheckAssoc = mysqli_fetch_assoc($result);
                            
                            $idd = $resultCheckAssoc['id'];
                            $name = $resultCheckAssoc['name'];
                            $email = $resultCheckAssoc['email'];
                            $top = $resultCheckAssoc['top'];
                            
                            echo '<section class = "order">
                                    <form class = "ordersNotResolved" action = "includes/resolveOrder.php" method = "post">
                                        <input name = "id" type = "hidden" value = "'.$idd.'">
                                        <button>Resolve</button>
                                    </form>
                                    <p>ID: '.$idd.'</p>
                                    <p>Name: '.$name.'</p>
                                    <p>E-mail: '.$email.'</p>
                                    <p>Time of Pickup: '.$top.'</p>
                                  </section>';
                            echo "\n";
                            $i++;
                            
                        } while ($i < $resultCheck);
                        
                    }
                
                ?>         
            </section>
        </main>
        <footer>
        </footer>
        <script>
            var contact = document.getElementById("contact");
            contact.style.backgroundColor = "#4D0000";
        </script>
    </body>
</html>